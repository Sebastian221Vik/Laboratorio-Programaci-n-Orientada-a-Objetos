package Ejercicio1;

public class Smartphone extends DispositivoMovil {
    private String procesador;
    private int horasbateria;

    public Smartphone(String procesador, int horasbateria, float precio) {
        super(precio);
        this.procesador = procesador;
        this.horasbateria = horasbateria;
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }

    public int getHorasbateria() {
        return horasbateria;
    }

    public void setHorasbateria(int horasbateria) {
        this.horasbateria = horasbateria;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: Smartphone");
        System.out.println("Procesador: " + this.getProcesador());
        System.out.println("Horas de utilidad: " + this.getHorasbateria());
        super.Caracteristicas();
    }
}
