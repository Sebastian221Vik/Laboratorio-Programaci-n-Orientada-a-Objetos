package Ejercicio1;

public interface DispositivoElectronico {

    float Precio();

    void Caracteristicas();
}
