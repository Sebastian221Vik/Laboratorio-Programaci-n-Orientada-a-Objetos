package Ejercicio1;

import java.util.ArrayList;

public abstract class Computadora implements DispositivoElectronico {
    float precio;
    static ArrayList<PC> pcs = new ArrayList<>();
    static ArrayList<Laptop> laptops = new ArrayList<>();

    public Computadora(float precio) {
        this.setPrecio(precio);
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public float Precio() {
        return this.precio;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("El precio del producto es: " + this.getPrecio());
    }

    public static void CrearPCs() {
        PC pc1 = new PC("Ryzen", 16, 1024, 12000);
        PC pc2 = new PC("Intel", 8, 516, 8000);
        PC pc3 = new PC("Ryzen", 32, 516, 15000);
        pcs.add(pc1);
        pcs.add(pc2);
        pcs.add(pc3);
    }

    public static void CrearLaptops() {
        Laptop lap1 = new Laptop(10000, "Windows", 6, 8);
        Laptop lap2 = new Laptop(12000, "Windows", 8, 8);
        Laptop lap3 = new Laptop(15000, "macOS", 8, 16);
        laptops.add(lap1);
        laptops.add(lap2);
        laptops.add(lap3);
    }

    public static void MostrarPCs() {
        int i = 0;
        for (PC actual : pcs) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }

    public static void MostrarLaptops() {
        int i = 0;
        for (Laptop actual : laptops) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }

}
