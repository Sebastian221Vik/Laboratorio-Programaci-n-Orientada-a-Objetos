package Ejercicio1;

public class Socio extends Comprador {

    public Socio(String nombre, int edad) {
        super(nombre, edad);
    }

    @Override
    public void Comprar(DispositivoElectronico dp) {
        this.compra += dp.Precio();
    }

    @Override
    public float Total() {
        return this.compra;
    }

}
