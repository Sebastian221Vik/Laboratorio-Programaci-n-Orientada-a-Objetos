package Ejercicio1;

public class Laptop extends Computadora {
    private String sistemaOperativo;
    private int numNucleos;
    private int ram;

    public Laptop(float precio, String sistemaOperativo, int numNucleos, int ram) {
        super(precio);
        this.setSistemaOperativo(sistemaOperativo);
        this.setNumNucleos(numNucleos);
        this.setRam(ram);
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public int getNumNucleos() {
        return numNucleos;
    }

    public void setNumNucleos(int numNucleos) {
        this.numNucleos = numNucleos;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: Laptop");
        System.out.println("Sistema Operativo: " + this.getSistemaOperativo());
        System.out.println("Numero de Nucleos: " + this.getNumNucleos());
        System.out.println("Memoria Ram: " + this.getRam());
        super.Caracteristicas();
    }
}
