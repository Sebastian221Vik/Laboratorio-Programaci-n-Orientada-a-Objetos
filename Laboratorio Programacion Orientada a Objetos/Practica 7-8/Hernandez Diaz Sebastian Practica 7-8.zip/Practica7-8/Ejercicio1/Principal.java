package Ejercicio1;

import java.util.Scanner;

public class Principal {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        String nombre;
        int edad;
        System.out.println("¿Que tipo de comprador eres?\n");
        System.out.println("1)ClienteVip\n2)Socio\n3)Estudiante");
        int op = scanner.nextInt();
        System.out.println("Ingrese su nombre");
        scanner.nextLine();
        nombre = scanner.nextLine();
        System.out.println("Ingrese su edad");
        edad = scanner.nextInt();
        System.out.println();
        switch (op) {
            case 1:
                Comprador clienteV = new ClienteVip(nombre, edad);
                System.out.println("Los articulos que usted puede comprar son:");
                System.out.println("PC, Laptop, Television, Celular, Smartphone y Tablet\n");
                Principal.Compras(clienteV);
                System.out.println("\nEl subtotal de su compra es de: " + clienteV.Total());
                System.out.println("Descuento del 15% al ser Cliente VIP: " + (clienteV.Total() * 0.15));
                System.out.println("El total de su compra es de: " + (clienteV.Total() - clienteV.Total() * 0.15));
                System.out.println("Que tenga un buen dia " + clienteV.nombre);
                break;
            case 2:
                Comprador clienteS = new Socio(nombre, edad);
                System.out.println("Los articulos que usted puede comprar son:");
                System.out.println("PC, Laptop, Smartphone y Tablet\n");
                Principal.Compras(clienteS);
                System.out.println("\nEl subtotal de su compra es de: " + clienteS.Total());
                System.out.println("Descuento del 10% al ser Socio: " + (clienteS.Total() * 0.10));
                System.out.println("El total de su compra es de: " + (clienteS.Total() - clienteS.Total() * 0.10));
                System.out.println("Que tenga un buen dia " + clienteS.nombre);
                break;
            case 3:
                Comprador clienteE = new Estudiante(nombre, edad);
                System.out.println("Los articulos que usted puede comprar son:");
                System.out.println("Laptop, Smartphone y Tablet\n");
                Principal.Compras(clienteE);
                System.out.println("\nEl subtotal de su compra es de: " + clienteE.Total());
                System.out.println("Descuento del 3% al ser Estudiante: " + (clienteE.Total() * 0.03));
                System.out.println("El total de su compra es de: " + (clienteE.Total() - clienteE.Total() * 0.03));
                System.out.println("Que tenga un buen dia " + clienteE.nombre);
                break;
            default:
                System.out.println("El valor ingresado no es valido");
                break;
        }
        scanner.close();
    }

    public static void Compras(Comprador cliente) {
        int r;
        int s;
        if (cliente.getClass() == ClienteVip.class || cliente.getClass() == Socio.class) {
            System.out.println("\nPresione 1 para ver las PC's");
            s = scanner.nextInt();
            if (s == 1) {
                Computadora.CrearPCs();
                Computadora.MostrarPCs();
                System.out.println("Presione 1 para comprar algun articulo");
                r = scanner.nextInt();
                if (r == 1) {
                    System.out.println("Dame el indice del articulo a comprar");
                    int com = scanner.nextInt();
                    Computadora cp = Computadora.pcs.get(com - 1);
                    cliente.Comprar(cp);
                }
            }
        }

        System.out.println("\nPresione 1 para ver las Laptops");
        s = scanner.nextInt();
        if (s == 1) {
            Computadora.CrearLaptops();
            Computadora.MostrarLaptops();
            System.out.println("Presione 1 para comprar algun articulo");
            r = scanner.nextInt();
            if (r == 1) {
                System.out.println("Dame el indice del articulo a comprar");
                int com = scanner.nextInt();
                Computadora cp = Computadora.laptops.get(com - 1);
                cliente.Comprar(cp);
            }
        }

        if (cliente.getClass() == ClienteVip.class) {
            System.out.println("\nPresione 1 para ver las televisiones");
            s = scanner.nextInt();
            if (s == 1) {
                Television.CrearTelevisiones();
                Television.MostrarTelevisiones();
                System.out.println("Presione 1 para comprar algun articulo");
                r = scanner.nextInt();
                if (r == 1) {
                    System.out.println("Dame el indice del articulo a comprar");
                    int com = scanner.nextInt();
                    Television cp = Television.televisiones.get(com - 1);
                    cliente.Comprar(cp);
                }
            }
        }
        if (cliente.getClass() == ClienteVip.class) {
            System.out.println("\nPresione 1 para ver los Celulares");
            s = scanner.nextInt();
            if (s == 1) {
                DispositivoMovil.CrearCelulares();
                DispositivoMovil.MostrarCelulares();
                System.out.println("Presione 1 para comprar algun articulo");
                r = scanner.nextInt();
                if (r == 1) {
                    System.out.println("Dame el indice del articulo a comprar");
                    int com = scanner.nextInt();
                    DispositivoMovil cp = DispositivoMovil.celulares.get(com - 1);
                    cliente.Comprar(cp);
                }
            }
        }

        System.out.println("\nPresione 1 para ver los SmartPhones");
        s = scanner.nextInt();
        if (s == 1) {
            DispositivoMovil.CrearSmartphones();
            DispositivoMovil.MostrarSmartPhones();
            System.out.println("Presione 1 para comprar algun articulo");
            r = scanner.nextInt();
            if (r == 1) {
                System.out.println("Dame el indice del articulo a comprar");
                int com = scanner.nextInt();
                DispositivoMovil cp = DispositivoMovil.smartphones.get(com - 1);
                cliente.Comprar(cp);
            }
        }

        System.out.println("\nPresione 1 para ver las Tablets");
        s = scanner.nextInt();
        if (s == 1) {
            DispositivoMovil.CrearTablets();
            DispositivoMovil.MostrarTablets();
            System.out.println("Presione 1 para comprar algun articulo");
            r = scanner.nextInt();
            if (r == 1) {
                System.out.println("Dame el indice del articulo a comprar");
                int com = scanner.nextInt();
                DispositivoMovil cp = DispositivoMovil.tablets.get(com - 1);
                cliente.Comprar(cp);
            }
        }
    }
}
