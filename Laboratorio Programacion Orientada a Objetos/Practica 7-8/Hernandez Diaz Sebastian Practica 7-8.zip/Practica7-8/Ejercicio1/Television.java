package Ejercicio1;

import java.util.ArrayList;

public class Television implements DispositivoElectronico {
    private float precio;
    private int pulgadas;
    private String resolucion;
    static ArrayList<Television> televisiones = new ArrayList<>();

    public Television(float precio, int pulgadas, String resolucion) {
        this.setPrecio(precio);
        this.setPulgadas(pulgadas);
        this.setResolucion(resolucion);
    }

    public String getResolucion() {
        return resolucion;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }

    public int getPulgadas() {
        return pulgadas;
    }

    public void setPulgadas(int pulgadas) {
        this.pulgadas = pulgadas;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public float Precio() {
        return this.precio;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: Television");
        System.out.println("Pulgadas: " + this.getPulgadas());
        System.out.println("Resolucion: " + this.getResolucion());
        System.out.println("Precio: " + this.getPrecio());
    }

    public static void CrearTelevisiones() {
        Television t1 = new Television(10000, 55, "4K UHD");
        Television t2 = new Television(13500, 65, "4K UHD");
        Television t3 = new Television(5000, 32, "HD");
        televisiones.add(t1);
        televisiones.add(t2);
        televisiones.add(t3);
    }

    public static void MostrarTelevisiones() {
        int i = 0;
        for (Television actual : televisiones) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }

}
