package Ejercicio1;

public class Tablet extends DispositivoMovil {
    private int ram;
    private int horasbateria;

    public Tablet(float precio, int ram, int horasbateria) {
        super(precio);
        this.setRam(ram);
        this.setHorasbateria(horasbateria);
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getHorasbateria() {
        return horasbateria;
    }

    public void setHorasbateria(int horasbateria) {
        this.horasbateria = horasbateria;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: Tablet");
        System.out.println("Memoria Ram: " + this.getRam());
        System.out.println("Horas de utilidad: " + this.getHorasbateria());
        super.Caracteristicas();
    }
}
