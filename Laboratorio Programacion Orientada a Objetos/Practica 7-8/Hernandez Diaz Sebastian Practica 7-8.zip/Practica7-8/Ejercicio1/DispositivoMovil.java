package Ejercicio1;

import java.util.ArrayList;

public abstract class DispositivoMovil implements DispositivoElectronico {
    float precio;
    static ArrayList<Celular> celulares = new ArrayList<>();
    static ArrayList<Smartphone> smartphones = new ArrayList<>();
    static ArrayList<Tablet> tablets = new ArrayList<>();

    public DispositivoMovil(float precio) {
        this.setPrecio(precio);
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("El precio del producto es: " + this.getPrecio());
    }

    @Override
    public float Precio() {
        return this.precio;
    }

    public static void CrearCelulares() {
        Celular cel1 = new Celular(3000, 2005, 10);
        Celular cel2 = new Celular(2500, 2006, 9);
        Celular cel3 = new Celular(2800, 2010, 12);
        celulares.add(cel1);
        celulares.add(cel2);
        celulares.add(cel3);
    }

    public static void CrearSmartphones() {
        Smartphone s1 = new Smartphone("Snapdragon", 8, 12000);
        Smartphone s2 = new Smartphone("Exynos", 7, 10000);
        Smartphone s3 = new Smartphone("A16 Bionic", 8, 15000);
        smartphones.add(s1);
        smartphones.add(s2);
        smartphones.add(s3);
    }

    public static void CrearTablets() {
        Tablet t1 = new Tablet(8000, 8, 10);
        Tablet t2 = new Tablet(9000, 8, 11);
        Tablet t3 = new Tablet(7000, 6, 9);
        tablets.add(t1);
        tablets.add(t2);
        tablets.add(t3);
    }

    public static void MostrarCelulares() {
        int i = 0;
        for (Celular actual : celulares) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }

    public static void MostrarSmartPhones() {
        int i = 0;
        for (Smartphone actual : smartphones) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }

    public static void MostrarTablets() {
        int i = 0;
        for (Tablet actual : tablets) {
            System.out.println("Indice del articulo: " + (i + 1));
            actual.Caracteristicas();
            System.out.println();
            i++;
        }
    }
}