package Ejercicio1;

public class PC extends Computadora {
    private String procesador;
    private int ram;
    private int memoria;

    public PC(String procesador, int ram, int memoria, float precio) {
        super(precio);
        this.setProcesador(procesador);
        this.setRam(ram);
        this.setMemoria(memoria);
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getMemoria() {
        return memoria;
    }

    public void setMemoria(int memoria) {
        this.memoria = memoria;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: PC");
        System.out.println("Procesador: " + this.getProcesador());
        System.out.println("Memoria Ram: " + this.getRam());
        System.out.println("Memoria: " + this.getMemoria());
        super.Caracteristicas();
    }

}
