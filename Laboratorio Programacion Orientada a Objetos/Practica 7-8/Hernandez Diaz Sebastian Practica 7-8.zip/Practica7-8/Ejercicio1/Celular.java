package Ejercicio1;

public class Celular extends DispositivoMovil {

    private int aniodefabricacion;
    private int horasbateria;

    public Celular(float precio, int aniodefabricacion, int horasbateria) {
        super(precio);
        this.setAniodefabricacion(aniodefabricacion);
        this.setHorasbateria(horasbateria);
    }

    public int getAniodefabricacion() {
        return aniodefabricacion;
    }

    public void setAniodefabricacion(int aniodefabricacion) {
        this.aniodefabricacion = aniodefabricacion;
    }

    public int getHorasbateria() {
        return horasbateria;
    }

    public void setHorasbateria(int horasbateria) {
        this.horasbateria = horasbateria;
    }

    @Override
    public void Caracteristicas() {
        System.out.println("Articulo: Celular");
        System.out.println("Año de fabricacion: " + this.getAniodefabricacion());
        System.out.println("Horas de utilidad: " + this.getHorasbateria());
        super.Caracteristicas();
    }

}
