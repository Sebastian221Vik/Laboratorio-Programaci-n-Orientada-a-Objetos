package Ejercicio2;

public class Gato extends Animales {
    private String color;

    public Gato(String nombre, float peso, int edad, String color) {
        super(nombre, peso, edad);
        this.setColor(color);

    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return this.color;
    }

    @Override
    public void Mostrar() {
        System.out.println("Animal: Gato");
        super.Mostrar();
        System.out.println("Color: " + this.getColor());
    }

    @Override
    public void Comiendo() {
        System.out.println("Estoy comiendo como gato");
    }

    @Override
    public void Sonido() {
        System.out.println("¡Miau Miau!");
    }
}
