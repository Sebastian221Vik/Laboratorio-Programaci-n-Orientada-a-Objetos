package Ejercicio2;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        ArrayList<Animales> animales = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int op;
        int eleccion;
        String nombre;
        float peso;
        int edad;
        do {
            System.out.println("\n1)Agregar un animal");
            System.out.println("2)Mostrar un elemento de la coleccion");
            System.out.println("3)Mostrar la coleccion completa");
            System.out.println("4)Salir");
            op = scanner.nextInt();
            switch (op) {
                case 1:
                    System.out.println("Lista de animales que puedes crear\n1)Perro\n2)Gato");
                    System.out.println("3)Caballo\n4)Oso\n5)Serpiente");
                    eleccion = scanner.nextInt();
                    System.out.println("Dame los datos del animal");
                    scanner.nextLine();
                    System.out.println("Dame el nombre");
                    nombre = scanner.nextLine();
                    System.out.println("Dame el peso en Kg");
                    peso = scanner.nextFloat();
                    System.out.println("Dame la edad en años");
                    edad = scanner.nextInt();
                    switch (eleccion) {
                        case 1:
                            scanner.nextLine();
                            System.out.println("Dame la raza del perro");
                            String raza = scanner.nextLine();
                            Animales perro1 = new Perro(nombre, peso, edad, raza);
                            animales.add(perro1);
                            break;
                        case 2:
                            scanner.nextLine();
                            System.out.println("Dame el color del gato");
                            String color = scanner.nextLine();
                            Animales gato1 = new Gato(nombre, peso, edad, color);
                            animales.add(gato1);
                            break;
                        case 3:
                            scanner.nextLine();
                            System.out.println("Dame el color del caballo");
                            String colorc = scanner.nextLine();
                            System.out.println("Dame la altura del caballo");
                            float altura = scanner.nextFloat();
                            Animales caballo = new Caballo(nombre, peso, edad, colorc, altura);
                            animales.add(caballo);
                            break;
                        case 4:
                            scanner.nextLine();
                            System.out.println("Dame el tipo de oso");
                            String tipo = scanner.nextLine();
                            Animales oso = new Oso(nombre, peso, edad, tipo);
                            animales.add(oso);
                            break;
                        case 5:
                            scanner.nextLine();
                            System.out.println("Dame el tipo de serpiente");
                            String tipo1 = scanner.nextLine();
                            Animales serpiente = new Serpiente(nombre, peso, edad, tipo1);
                            animales.add(serpiente);
                            break;
                        default:
                            System.out.println("La opcion dada no es valida");
                            break;
                    }
                    break;
                case 2:
                    System.out.println("Dame el indice del animal a mostrar");
                    int indice = scanner.nextInt();
                    Animales animal1 = animales.get(indice);
                    animal1.Mostrar();
                    animal1.Comiendo();
                    animal1.Sonido();
                    break;
                case 3:
                    int i = 0;
                    for (Animales an : animales) {
                        System.out.println("\nIndice del Animal: " + i);
                        an.Mostrar();
                        an.Comiendo();
                        an.Sonido();
                        System.out.println();
                        i++;
                    }
                    break;
                case 4:
                    System.out.println("Hasta luego");
                    break;
                default:
                    System.out.println("La opcion ingresada no es valida");
                    break;
            }
        } while (op != 4);
        scanner.close();
    }
}
