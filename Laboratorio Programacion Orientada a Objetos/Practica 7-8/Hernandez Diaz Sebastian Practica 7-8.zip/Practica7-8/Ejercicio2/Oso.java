package Ejercicio2;

public class Oso extends Animales {
    private String tipo;

    public Oso(String nombre, float peso, int edad, String tipo) {
        super(nombre, peso, edad);
        this.setTipo(tipo);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public void Mostrar() {
        System.out.println("Animal: Oso");
        super.Mostrar();
        System.out.println("Tipo: " + this.getTipo());
    }

    @Override
    public void Comiendo() {
        System.out.println("Estoy comiendo como oso");
    }

    @Override
    public void Sonido() {
        System.out.println("¡Grrr Grrr!");
    }
}
