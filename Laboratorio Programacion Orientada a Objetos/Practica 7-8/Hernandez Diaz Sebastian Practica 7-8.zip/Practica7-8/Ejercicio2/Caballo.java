package Ejercicio2;

public class Caballo extends Animales {
    private String color;
    private float altura;

    public Caballo(String nombre, float peso, int edad, String color, float altura) {
        super(nombre, peso, edad);
        this.setColor(color);
        this.setAltura(altura);
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return this.color;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        if (altura>0){
            this.altura = altura;
        }
    }

    @Override
    public void Mostrar() {
        System.out.println("Animal: Caballo");
        super.Mostrar();
        System.out.println("Color: " + this.getColor());
        System.out.println("Altura: " + this.getAltura());
    }

    @Override
    public void Comiendo() {
        System.out.println("Estoy comiendo como caballo");
    }

    @Override
    public void Sonido() {
        System.out.println("¡Hiii, hiii!");
    }
}
