package Ejercicio2;

public abstract class Animales {
    private String nombre;
    private float peso;
    private int edad;

    public Animales(String nombre, float peso, int edad) {
        this.setNombre(nombre);
        this.setPeso(peso);
        this.setEdad(edad);
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setPeso(float peso) {
        if (peso>0){
            this.peso = peso;
        }
    }

    public float getPeso() {
        return this.peso;
    }

    public void setEdad(int edad) {
        if (edad>0){
            this.edad = edad;
        }
    }

    public int getEdad() {
        return this.edad;
    }

    public void Mostrar() {
        System.out.println("Nombre: " + this.getNombre());
        System.out.println("Peso: " + this.getPeso());
        System.out.println("Edad: " + this.getEdad());
    }

    public abstract void Comiendo();

    public abstract void Sonido();

}
