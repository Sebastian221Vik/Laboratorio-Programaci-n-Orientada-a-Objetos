package Ejercicio2;

public class Perro extends Animales {
    private String raza;

    public Perro(String nombre, float peso, int edad, String raza) {
        super(nombre, peso, edad);
        this.setRaza(raza);
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getRaza() {
        return this.raza;
    }

    @Override
    public void Mostrar() {
        System.out.println("Animal: Perro");
        super.Mostrar();
        System.out.println("Raza: " + this.getRaza());
    }

    @Override
    public void Comiendo() {
        System.out.println("Estoy comiendo como perro");
    }

    @Override
    public void Sonido() {
        System.out.println("¡Guau Guau!");
    }
}
