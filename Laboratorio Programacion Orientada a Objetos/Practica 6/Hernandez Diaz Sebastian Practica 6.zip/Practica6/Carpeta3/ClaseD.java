package Carpeta3;

import Carpeta1.Carpeta2.Perro;

public class ClaseD {
    Perro perro = new Perro();

    public void Clase() {
        System.out.println("\nEstoy dentro de la ClaseD");
        System.out.println("Hablar de la clase Perro desde la ClaseD:");
        perro.Clase();
    }
}
