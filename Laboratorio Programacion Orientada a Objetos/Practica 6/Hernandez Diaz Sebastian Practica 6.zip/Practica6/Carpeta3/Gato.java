package Carpeta3;

import Carpeta1.*;
import Carpeta1.Carpeta2.*;

public class Gato {
    public void Clase() {
        System.out.println("\nEstoy dentro de la Clase Gato Miau!!");
    }

    public static void main(String[] args) {
        ClaseA claseAobjeto = new ClaseA();
        ClaseB claseBobjeto = new ClaseB();
        System.out.println("Estoy en la clase Principal De Gato");
        claseAobjeto.Clase();
        claseBobjeto.Clase();

    }
}
