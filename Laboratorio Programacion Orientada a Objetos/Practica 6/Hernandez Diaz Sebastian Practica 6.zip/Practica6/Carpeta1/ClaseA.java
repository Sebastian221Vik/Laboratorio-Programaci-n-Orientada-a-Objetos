package Carpeta1;

import Carpeta3.ClaseD;

public class ClaseA {
    ClaseD claseDobjeto = new ClaseD();

    public void Clase() {
        System.out.println("\nEstoy dentro de la ClaseA");
        System.out.println("Hablar de la ClaseD desde la ClaseA:");
        claseDobjeto.Clase();
    }

}
