package Carpeta1.Carpeta2;

public class Perro {
    public void Clase() {
        System.out.println("\nEstoy dentro de la Clase Perro Guau!!");
    }
}
