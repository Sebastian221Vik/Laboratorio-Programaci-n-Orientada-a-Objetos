package Carpeta1.Carpeta2;

import Carpeta3.*;
import Carpeta1.*;

public class ClaseB {
    public void Clase() {
        Gato gato = new Gato();
        System.out.println("\nEstoy dentro de la ClaseB");
        gato.Clase();
    }

    public static void main(String[] args) {
        ClaseA claseAobjeto = new ClaseA();
        ClaseB claseBobjeto = new ClaseB();
        System.out.println("Estoy en la clase Principal");
        claseAobjeto.Clase();
        claseBobjeto.Clase();

    }
}
