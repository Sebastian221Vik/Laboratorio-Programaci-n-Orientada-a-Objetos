package Carpeta1;

import Carpeta1.Carpeta2.*;

public class Principal {
    public static void main(String[] args) {
        ClaseA claseAobjeto = new ClaseA();
        ClaseB claseBobjeto = new ClaseB();
        System.out.println("Estoy en la clase Principal");
        claseAobjeto.Clase();
        claseBobjeto.Clase();

    }
}
