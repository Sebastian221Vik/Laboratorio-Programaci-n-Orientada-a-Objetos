public class ExcepcionClave extends Exception {
    public ExcepcionClave() {
        System.out.println("La clave dada no es correcta");
        System.out.println("Debe de tener 4 digitos");
    }
}
