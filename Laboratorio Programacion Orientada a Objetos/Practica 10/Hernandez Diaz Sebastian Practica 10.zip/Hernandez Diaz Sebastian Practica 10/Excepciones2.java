import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

//TERCER ARCHIVO
public class Excepciones2 {

    public static void main(String[] args) throws IOException {
        manejoDeArchivos();
    }

    private static void manejoDeArchivos() throws FileNotFoundException, IOException {
        BufferedReader fileInput;
        FileReader file = new FileReader("Practica10POO.txt");
        fileInput = new BufferedReader(file);
        for (int counter = 0; counter < 3; counter++) {
            System.out.println(fileInput.readLine());
        }
        fileInput.close();
    }
}
