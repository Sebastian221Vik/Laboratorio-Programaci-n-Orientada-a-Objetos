import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<Alumnos> ListaAlumnos = new ArrayList<>();
    static int num;

    public static void main(String[] args)
            throws ExcepcionNumCuenta, ExcepcionClave, ExcepcionNombre, ExcepcionNumNombre {
        int i;
        try {
            scanner.nextLine();
            System.out.println("Ingrese el numero de alumnos a registrar");
            num = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Se debe de ingresar un numero entero positivo");
            main(args);
        }
        for (i = 0; i < num; i++) {
            Ciclo(num);
        }
        for (i = 0; i < ListaAlumnos.size(); i++) {
            System.out.println("\n\nDatos del alumno: " + ListaAlumnos.get(i).getNombre() + " " + ListaAlumnos.get(i)
                    .getApellido());
            System.out.println("Numero de cuenta: " + ListaAlumnos.get(i).getNumCuenta());
            int lista[] = ListaAlumnos.get(i).getAsignaturas();
            for (int j = 0; j < 3; j++) {
                System.out.println("Clave de la asignatura " + (j + 1) + ": " + lista[j]);
            }
        }
    }

    public static void Ciclo(int num) throws ExcepcionNumCuenta, ExcepcionClave, ExcepcionNombre, ExcepcionNumNombre {
        try {
            ListaAlumnos.add(Datos());
        } catch (ExcepcionNumCuenta e) {
            System.out.println("Intentalo de nuevo");
            Ciclo(num - ListaAlumnos.size());
        } catch (ExcepcionClave e) {
            System.out.println("Intentalo de nuevo");
            Ciclo(num - ListaAlumnos.size());
        } catch (ExcepcionNombre e) {
            System.out.println("Intentalo de nuevo");
            Ciclo(num - ListaAlumnos.size());
        } catch (ExcepcionNumNombre e) {
            Ciclo(num - ListaAlumnos.size());
        }
    }

    public static Alumnos Datos() throws ExcepcionNumCuenta, ExcepcionClave, ExcepcionNombre, ExcepcionNumNombre {
        int numCuenta = 0;
        String nombre;
        String apellido;
        int i;
        int asignaturas[] = new int[3];
        Alumnos Alu;
        try {
            scanner.nextLine();
            System.out.println("\nDame el numero de cuenta del alumno");
            numCuenta = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Debe de dar un numero entero");
            scanner.nextLine();
            Datos();
        }
        if (numCuenta < 100000000 || numCuenta > 999999999) {
            throw new ExcepcionNumCuenta();
        }
        System.out.println("Dame el nombre del alumno");
        scanner.nextLine();
        nombre = scanner.nextLine();
        if (nombre.matches(".*[0-9].*")) {
            throw new ExcepcionNumNombre();
        }
        if (nombre.length() < 4) {
            throw new ExcepcionNombre();
        }
        System.out.println("Dame el apellido del alumno");
        apellido = scanner.nextLine();
        if (apellido.matches(".*[0-9].*")) {
            throw new ExcepcionNumNombre();
        }
        if (apellido.length() < 4) {
            throw new ExcepcionNombre();
        }
        for (i = 0; i < 3; i++) {
            try {
                System.out.println("Dame la clave de la asignatura: " + (i + 1));
                asignaturas[i] = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("El valor ingresado debe de ser un numero entero");
                Datos();
            }
            if (asignaturas[i] < 1000 || asignaturas[i] > 9999) {
                throw new ExcepcionClave();
            }
        }
        Alu = new Alumnos(numCuenta, nombre, apellido, asignaturas);
        return Alu;
    }
}
