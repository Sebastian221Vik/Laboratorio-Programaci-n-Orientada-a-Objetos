public class ExcepcionNumNombre extends Exception {
    public ExcepcionNumNombre() {
        System.out.println("El nombre o apellido no pueden contener numeros");
        System.out.println("Intentelo de nuevo");
    }
}
