public class ExcepcionNumCuenta extends Exception {
    public ExcepcionNumCuenta() {
        System.out.println("El numero de cuenta no es correcto");
        System.out.println("Debe de tener 9 digitos");
    }
}
