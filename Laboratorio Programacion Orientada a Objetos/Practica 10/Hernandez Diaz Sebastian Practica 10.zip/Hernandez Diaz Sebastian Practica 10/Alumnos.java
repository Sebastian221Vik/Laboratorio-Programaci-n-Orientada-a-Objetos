public class Alumnos {
    private int numCuenta;
    private String nombre;
    private String apellido;
    private int asignaturas[] = new int[3];

    public Alumnos(int numCuenta, String nombre, String apellido, int[] asignaturas) {
        this.numCuenta = numCuenta;
        this.nombre = nombre;
        this.apellido = apellido;
        this.asignaturas = asignaturas;
    }

    public int[] getAsignaturas() {
        return asignaturas;
    }

    public void setAsignaturas(int[] asignaturas) {
        this.asignaturas = asignaturas;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

}
