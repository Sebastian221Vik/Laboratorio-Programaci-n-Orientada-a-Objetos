import java.util.InputMismatchException;
import java.util.Scanner;

//PRIMER ARCHIVO
public class Excepciones {

    private Scanner teclado;
    static int oportunidades = 3;

    public static void main(String[] args) {
        Excepciones prueba = new Excepciones();
        prueba.leerDatos();
    }

    private void leerDatos() {
        teclado = new Scanner(System.in);
        int dividendo = 1;
        int divisor = 1;
        try {
            System.out.println("Introduce dividendo");
            dividendo = teclado.nextInt();
            System.out.println("Introduce divisor");
            divisor = teclado.nextInt();
            metodoDividir(dividendo, divisor);
        } catch (InputMismatchException e) {
            if (oportunidades > 0) {
                System.out.println("El valor ingresado debe ser un numero");
                System.out.println("Intentalo otra vez, numero de intentos restantes: " + oportunidades);
                oportunidades -= 1;
                leerDatos();
            }
            if (oportunidades == 0) {
                System.out.println("Tus oportunidades se han terminado");
            }
        }
    }

    private void metodoDividir(int dividendo, int divisor) {
        int resultado = 0;
        try {
            resultado = dividendo / divisor;
            System.out.println("El resultado es:  " + resultado);
        } catch (ArithmeticException e) {
            System.out.println("Error de usuario, no se puede dividir entre cero");
            System.out.println("Intentalo de nuevo");
            leerDatos();
        }
    }
}
