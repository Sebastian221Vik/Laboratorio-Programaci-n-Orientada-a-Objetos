import java.util.Calendar;

//SEGUNDO ARCHIVO
public class Excepciones4 {

    private static final String CLASS_TO_LOAD = "java.util.Calendar2";

    public static void main(String[] args) {
        Entrada();
    }

    public static void Entrada() {
        System.out.println("Bienvenido al programa");
        System.out.println("vamos a buscar la clase");
        try {
            buscarClase();
        } catch (ClassNotFoundException e) {
            System.out.println("La clase que se esta buscando no se encontro");
        }
    }

    private static void buscarClase() throws ClassNotFoundException {
        Class loadedClass = Class.forName(CLASS_TO_LOAD);
        System.out.println("Class " + loadedClass + " found successfully!");
    }

}
