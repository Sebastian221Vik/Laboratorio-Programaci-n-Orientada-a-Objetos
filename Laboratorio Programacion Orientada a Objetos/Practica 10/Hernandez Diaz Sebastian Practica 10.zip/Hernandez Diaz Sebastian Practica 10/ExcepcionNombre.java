public class ExcepcionNombre extends Exception {
    public ExcepcionNombre() {
        System.out.println("El nombre o apellido deben de tener al menos 4 caracteres");
    }
}
