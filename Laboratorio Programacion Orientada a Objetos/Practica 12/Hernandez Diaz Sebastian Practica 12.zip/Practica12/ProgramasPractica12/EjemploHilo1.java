public class EjemploHilo1 extends Thread{
    public EjemploHilo1(String name) {
        super(name);
        
    }
    @Override
    public void run(){
        for (int i=0; i<6; i++){
            if (i==3){
                Thread.currentThread().setName(Thread.currentThread().getName()+"V2");
            }
            System.out.println(i + " "+getName());
        }
        System.out.println("Termina el hilo "+getName()); 
    }
    
    public static void main(String[] args) throws InterruptedException {
        EjemploHilo1 uno = new EjemploHilo1("Mexico");
        EjemploHilo1 dos = new EjemploHilo1("Brasil");
        Thread tres = new EjemploHilo1("Alemania");
        Thread cuatro = new EjemploHilo1("España");
        Thread cinco = new EjemploHilo1("Francia");
        Thread seis = new EjemploHilo1("Inglaterra");
        uno.start();
        dos.start();
        tres.start();
        tres.join();
        cuatro.start();
        cinco.start();
        seis.start();
    }
    
}


