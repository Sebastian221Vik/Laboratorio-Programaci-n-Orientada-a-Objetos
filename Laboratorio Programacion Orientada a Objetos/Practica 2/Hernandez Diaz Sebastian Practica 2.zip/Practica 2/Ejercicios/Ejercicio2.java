import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Inserte un mes del año en palabra");
        String mes = scanner.nextLine();
        int dias;
        switch (mes) {
            case "enero":
                dias = 31;
                break;
            case "febrero":
                dias = 28;
                break;
            case "marzo":
                dias = 31;
                break;
            case "abril":
                dias = 30;
                break;
            case "mayo":
                dias = 31;
                break;
            case "junio":
                dias = 30;
                break;
            case "julio":
                dias = 31;
                break;
            case "agosto":
                dias = 31;
                break;
            case "septiembre":
                dias = 30;
                break;
            case "octubre":
                dias = 31;
                break;
            case "noviembre":
                dias = 30;
                break;
            case "diciembre":
                dias = 31;
                break;
            default:
                dias = 0;
                break;
        }
        System.out.println("El mes de " + mes + " tiene " + dias + " dias");
        scanner.close();
    }
}
