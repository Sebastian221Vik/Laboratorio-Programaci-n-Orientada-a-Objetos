public class Ejercicio3 {
    public static void main(String[] args) {
        int x = 10;
        int y = 10;
        int z;
        z = x <= 10 && y <= 10 ? x > 5 && y < 5 ? 200 : 100 : 50;
        System.out.println(z);

        String c;
        int p = 10;
        c = p > 6 ? p < 7.4 ? "suficiente" : p < 8.4 ? "Buen trabajo" : "Excelente" : "Lo siento, deberas recursar";
        System.out.println(c);
    }
}
