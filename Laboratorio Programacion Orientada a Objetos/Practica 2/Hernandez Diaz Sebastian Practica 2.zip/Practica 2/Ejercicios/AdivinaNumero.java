import java.util.Scanner;
import java.util.Random;

public class AdivinaNumero {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random aleatorio = new Random();
        int numeroSecreto;
        numeroSecreto = aleatorio.nextInt(10)+1;
        
        System.out.println("Bienvenido al juego:  ADIVINA EL NÚMERO");
        System.out.println("Escribe el numero:");
        int numero = sc.nextInt();
        if(numero == numeroSecreto){
            System.out.println("Felicidades, adivinaste");
        }
        else if(numero > numeroSecreto ){
            System.out.println("El numero que ingresaste es mayor, intenta de nuevo");
            numero = sc.nextInt();
            if(numero == numeroSecreto){
                System.out.println("Felicidades, adivinaste");
            }
            else{
                System.out.println("No adivinaste, el número era: "+ numeroSecreto);
            }
        }
        else{
            System.out.println("El numero que ingresaste es menor, intenta de nuevo");
                numero = sc.nextInt();
            if(numero == numeroSecreto){
                System.out.println("Felicidades, adivinaste");
            }
            else{
                System.out.println("No adivinaste, el número era: "+ numeroSecreto);
            }
        }
        
        
    }
    
}
