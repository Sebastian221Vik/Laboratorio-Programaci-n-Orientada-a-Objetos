public class Ejercicio1 {
    public static void main(String[] args) {
        int a = 10;
        int b = 3;
        long c = 300_000_000;
        float d = 55.32f;
        System.out.println(a / b);
        System.out.println(c);
        System.out.println(d);
    }
}
