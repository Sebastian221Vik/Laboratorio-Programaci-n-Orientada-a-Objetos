public class Ejercicio5 {
    public static void main(String[] args) {
        int a[] = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
        int var = 0;
        int var2 = 10;
        // El error es que es for each no toma indices sino valores, no va 0,1,2 sino
        // 5,10,15,20
        for (int i : a) {
            var += i;
        }
        for (int i : a) {
            i = i * 10;
        }
        for (int i : a) {
            if (i % 4 == 0) {
                System.out.println(i + " es divisible entre 4");
            }
        }
        System.out.println(var + var2);
    }
}
