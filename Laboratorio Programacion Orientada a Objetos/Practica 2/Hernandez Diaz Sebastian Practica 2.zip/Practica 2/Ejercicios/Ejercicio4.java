import java.util.Scanner;
import java.util.Random;

public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random aleatorio = new Random();
        int numeroSecreto;
        int oportunidades = 8;
        int numero;
        numeroSecreto = aleatorio.nextInt(500) + 1;

        System.out.println("Bienvenido al juego:  ADIVINA EL NÚMERO");
        do {
            System.out.println("\nEscribe el numero:");
            numero = sc.nextInt();
            if (numero > numeroSecreto) {
                System.out.println("El numero que ingresaste es mayor");
                oportunidades -= 1;
            } else if (numero < numeroSecreto) {
                System.out.println("El numero que ingresaste es menor");
                oportunidades -= 1;
            } else {
                System.out.println("!!!Felicidades acertaste¡¡¡");
            }
            if (oportunidades == 0) {
                System.out.println("\nLo siento has perdido");
            }
        } while (numero != numeroSecreto && oportunidades > 0);
        sc.close();
    }
}
