import java.util.ArrayList;
import java.util.Scanner;

public class Practica4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        String Procesador, PlacaMadre;
        int memoria, Ram, FuentePoder;

        Computadora Pc = new Computadora();
        ArrayList<Computadora> ListaComputadoras = new ArrayList<Computadora>();
        do {
            System.out.println("\nPresiona 1) Para Crear una computadora");
            System.out.println("Presiona 2) Para Modificar una computadora");
            System.out.println("Presiona 3) Para Ver computadoras actuales");
            System.out.println("Presiona 4) Para Eliminar una computadora");
            System.out.println("Presiona 5) Para Salir");
            opcion = scanner.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("\nElegiste crear una nueva computadora\n");
                    Computadora Pc2 = Pc.DameDatos();
                    ListaComputadoras.add(Pc2);
                    break;
                case 2:
                    System.out.println("\nElegiste Modificar una computadora\n");
                    scanner.nextLine();
                    System.out.println("Dame el indice de la Computadora a modificar");
                    int modificar = scanner.nextInt();
                    int modi;
                    do {
                        System.out.println("Opciones de modificacion: ");
                        System.out.println("Presiona 1) Para Modificar El Procesador, Memoria y Ram");
                        System.out.println("Presiona 2) Para Modificar La Fuente de Poder y Placa Madre");
                        System.out.println("Presiona 3) Para Modificar El Procesador y Ram");
                        System.out.println("Presiona 4) Para terminar las modificaciones");
                        modi = scanner.nextInt();
                        switch (modi) {
                            case 1:
                                scanner.nextLine();
                                System.out.println("Dime la marca del procesador");
                                Procesador = scanner.nextLine();
                                System.out.println("Dime la cantidad de memoria");
                                memoria = scanner.nextInt();
                                System.out.println("Dime la cantidad de Ram");
                                Ram = scanner.nextInt();
                                ListaComputadoras.get(modificar).Cambio(Procesador, memoria, Ram);
                                break;
                            case 2:
                                System.out.println("Dame la cantidad de watts de la fuente de poder");
                                FuentePoder = scanner.nextInt();
                                System.out.println("Dame la marca de la placa madre");
                                scanner.nextLine();
                                PlacaMadre = scanner.nextLine();
                                ListaComputadoras.get(modificar).Cambio(FuentePoder, PlacaMadre);
                                break;
                            case 3:
                                scanner.nextLine();
                                System.out.println("Dime la marca del procesador");
                                Procesador = scanner.nextLine();
                                System.out.println("Dime la cantidad de Ram");
                                Ram = scanner.nextInt();
                                ListaComputadoras.get(modificar).Cambio(Procesador, Ram);
                        }
                    } while (modi != 4);
                    break;
                case 3:
                    System.out.println("\nElegiste Ver computadoras actuales: \n");
                    int i = 0;
                    for (Computadora elemento : ListaComputadoras) {
                        System.out.println("El indice de la Pc es: " + i);
                        elemento.MostrarDatos();
                        System.out.println();
                        i++;
                    }
                    break;
                case 4:
                    System.out.println("\nElegiste Eliminar una computadora\n");
                    System.out.println("Dame el indice de la Computadora a eliminar");
                    int borrar = scanner.nextInt();
                    ListaComputadoras.remove(borrar);
                    System.out.println("La computadora fue eliminada.");
                    break;
                case 5:
                    System.out.println("\nHasta Luego");
                    break;
                default:
                    System.out.println("La opcion no es valida");
                    break;
            }
        } while (opcion != 5);
        scanner.close();
    }

}
