public class PruebaPunto2 {
    public static void main(String[] args) {
        Punto2 p = new Punto2(5, 8);
        p.imprimePunto();
        Punto2 x = new Punto2();
        x.x = 7;
        x.y = 2;
        x.imprimePunto();
    }
}
