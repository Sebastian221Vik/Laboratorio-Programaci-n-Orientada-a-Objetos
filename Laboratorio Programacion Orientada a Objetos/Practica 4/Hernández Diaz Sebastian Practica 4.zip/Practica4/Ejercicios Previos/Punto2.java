public class Punto2 {
    int x, y;

    public Punto2(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public Punto2() {
    }

    public void imprimePunto() {
        System.out.println("Punto x=[" + x + ", y=" + y + "]");
    }
}
