public class Punto {
    int x, y;

    public void imprimePunto() {
        System.out.println("Punto x=[" + x + ", y=" + y + "]");
    }
}