public class Ejercicio5 {
    public static void main(String[] args) {
        /*
         * Int a = 23;
         * float 23 = 3.14;
         * double d@t@s = 9.811956;
         * char _Var = "Hola";
         * int null = 24;
         * int Null = 10.6;
         * string cadena = "hola";
         */
        int a = 23;
        float PI = 3.14f;
        double datos = 9.811956;
        String _Var = "Hola";
        int nul = 24;
        double Null = 10.6;
        String cadena = "hola";

    }
}
