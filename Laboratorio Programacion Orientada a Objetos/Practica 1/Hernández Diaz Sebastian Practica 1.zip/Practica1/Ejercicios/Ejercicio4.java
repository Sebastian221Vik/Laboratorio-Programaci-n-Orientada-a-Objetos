public class Ejercicio4 {
    public static void main(String[] args) {
        System.out.printf("La suma es: %d\n", Calculadora.Suma(6, 4));
        System.out.printf("La resta es: %d\n", Calculadora.Resta(20, 5));
        System.out.printf("La multiplicacion es: %d\n", Calculadora.Multiplicacion(4, 7));
        System.out.printf("El modulo es: %d\n", Calculadora.Modulo(10, 4));
    }
}
