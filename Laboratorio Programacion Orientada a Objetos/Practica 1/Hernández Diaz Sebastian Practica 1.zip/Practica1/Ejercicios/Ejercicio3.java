public class Ejercicio3 {

	public static void main(String[] args) {
		
		int a;
		a = 40;
		System.out.println("a vale: " + a);
		Clase1.metodo1();
		a = Clase1.metodo2();
		System.out.println("Ahora a vale: " + a);
		Clase2.metodo1();
		Clase3.metodo8();
	}

}