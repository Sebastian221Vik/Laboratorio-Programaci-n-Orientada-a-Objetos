public class Calculadora {
    public static int Suma(int a, int b) {
        return a + b;
    }

    public static int Resta(int a, int b) {
        return a - b;
    }

    public static int Multiplicacion(int a, int b) {
        return a * b;
    }

    public static int Modulo(int a, int b) {
        return a % b;
    }
}
