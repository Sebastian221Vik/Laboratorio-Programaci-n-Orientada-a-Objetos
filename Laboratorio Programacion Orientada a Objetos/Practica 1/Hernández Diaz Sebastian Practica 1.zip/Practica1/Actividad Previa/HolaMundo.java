public class HolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        System.out.println("Esta es mi clase");
    }
}