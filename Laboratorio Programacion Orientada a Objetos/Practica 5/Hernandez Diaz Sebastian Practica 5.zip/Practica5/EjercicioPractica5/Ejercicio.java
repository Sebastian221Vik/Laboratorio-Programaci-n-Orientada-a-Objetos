
import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        ArrayList<Tienda> tiendas = new ArrayList<>();
        Tienda tienda1 = new Tienda();
        Tienda Tiendatemp = new Tienda();
        do {
            System.out.println("\n¿Que deseas hacer?");
            System.out.println("1)Crear una Tienda Departamental\n2)Mostrar tiendas");
            System.out.println("3)Para salir");
            opcion = scanner.nextInt();
            switch (opcion) {
                case 1:
                    Tiendatemp = tienda1.Crear();
                    tiendas.add(Tiendatemp);
                    break;
                case 2:
                    for (Tienda t : tiendas) {
                        System.out.println("\n");
                        t.MostrarTienda();
                    }
                    break;
                case 3:
                    System.out.println("\nHasta luego");
                    break;
            }
        } while (opcion != 3);
        scanner.close();
    }
}