
import java.util.ArrayList;
import java.util.Scanner;

public class Producto {
	Scanner scanner = new Scanner(System.in);
	private String nombre;
	private float precio;
	private int unidades;
	static int creado = 0;
	int numpro;
	ArrayList<Producto> productos = new ArrayList<>();

	public Producto() {
	}

	public Producto(String nombre, float precio, int unidades) {
		creado += 1;
		this.setNombre(nombre);
		this.setPrecio(precio);
		this.setUnidades(unidades);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		if (precio > 0) {
			this.precio = precio;
		}
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int unidades) {
		if (unidades > 0) {
			this.unidades = unidades;
		}
	}

	public void Crear() {
		System.out.println("Dame el numero de productos");
		numpro = scanner.nextInt();
		for (int i = 0; i < numpro; i++) {
			scanner.nextLine();
			System.out.println("Dame el nombre del producto");
			nombre = scanner.nextLine();
			System.out.println("Dame el precio del producto");
			precio = scanner.nextFloat();
			scanner.nextLine();
			System.out.println("Dame las unidades por producto");
			unidades = scanner.nextInt();
			Producto producto = new Producto(nombre, precio, unidades);
			productos.add(producto);
		}
	}

	public void MostrarDatos() {
		System.out.println("\nEl numero de productos son: " + creado);
		for (Producto product : productos) {
			System.out.println("El nombre es: " + product.getNombre());
			System.out.println("El precio es: " + product.getPrecio());
			System.out.println("Las unidades por producto son: " + product.getUnidades());
		}
	}
}