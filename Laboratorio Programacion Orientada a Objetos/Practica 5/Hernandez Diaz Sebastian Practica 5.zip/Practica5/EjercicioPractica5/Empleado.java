
import java.util.ArrayList;
import java.util.Scanner;

public class Empleado {
    Scanner scanner = new Scanner(System.in);
    private String nombre;
    private int edad;
    private String rango;
    static int creados = 0;
    int numemp;
    ArrayList<Empleado> empleados = new ArrayList<>();

    public Empleado() {
    }

    public Empleado(String nombre, int edad, String rango) {
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setRango(rango);
        creados += 1;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setEdad(int edad) {
        if (edad > 17) {
            this.edad = edad;
        }
    }

    public int getEdad() {
        return edad;
    }

    public String getRango() {
        return rango;
    }

    public void setRango(String rango) {
        this.rango = rango;
    }

    public void Crear() {
        System.out.println("Dame el numero de empleados del departamento");
        numemp = scanner.nextInt();
        for (int i = 0; i < numemp; i++) {
            scanner.nextLine();
            System.out.println("Dame el nombre del empleado");
            nombre = scanner.nextLine();
            System.out.println("Dame la edad del empleado");
            edad = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Dame el rango del empleado");
            rango = scanner.nextLine();
            Empleado empleado = new Empleado(nombre, edad, rango);
            empleados.add(empleado);
        }
    }

    public void MostrarEmpleado() {
        System.out.println("\nEl numero de empleados son: " + creados);
        for (Empleado emple : empleados) {
            System.out.println("El nombre del empleado es: " + emple.getNombre());
            System.out.println("La edad del empleado es: " + emple.getEdad());
            System.out.println("El rango del empleado es: " + emple.getRango());
        }
    }
}
