import java.util.Scanner;

public class Tienda {
    Scanner scanner = new Scanner(System.in);
    private String nombre;
    private int codigo;
    private Gerente gerente;
    private Departamento departamento;

    public Tienda() {
    }

    public Tienda(String nombre, int codigo, Gerente gerente, Departamento departamento) {
        this.setNombre(nombre);
        this.setCodigo(codigo);
        this.setGerente(gerente);
        this.setDepartamento(departamento);
        System.out.println("Creaste una tienda");

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if (codigo > 0) {
            this.codigo = codigo;
        }
    }

    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        this.gerente = gerente;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Tienda Crear() {
        scanner.nextLine();
        System.out.println("Dame el nombre de la tienda");
        nombre = scanner.nextLine();
        System.out.println("Dame el codigo de la tienda");
        codigo = scanner.nextInt();
        System.out.println("Datos del gerente:");
        gerente = new Gerente();
        gerente = gerente.Crear();
        System.out.println("Datos de los departamentos:");
        departamento = new Departamento();
        departamento.Crear();
        Tienda t1 = new Tienda(nombre, codigo, gerente, departamento);
        return t1;
    }

    public void MostrarTienda() {
        int op;
        System.out.println("\tDatos de la tienda");
        System.out.println("EL nombre de la tienda es: " + this.getNombre());
        System.out.println("El codigo de la tienda es: " + this.getCodigo());
        System.out.println("Datos del gerente:");
        this.gerente.MostrarDatos();
        System.out.println("Presiona 1 para poder ver los departamentos de la tienda");
        op = scanner.nextInt();
        if (op == 1) {
            this.getDepartamento().MostrarDepartamentos();
        }
    }
}