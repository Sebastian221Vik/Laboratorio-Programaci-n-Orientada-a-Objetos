import java.util.Scanner;

public class Gerente {
    Scanner scanner = new Scanner(System.in);
    private String nombre;
    private int edad;
    private float salario;

    public Gerente() {
    }

    public Gerente(String nombre, int edad, float salario) {
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setSalario(salario);
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setEdad(int edad) {
        if (edad > 17) {
            this.edad = edad;
        }
    }

    public int getEdad() {
        return edad;
    }

    public void setSalario(float salario) {
        if (salario > 0) {
            this.salario = salario;
        }
    }

    public float getSalario() {
        return salario;
    }

    public Gerente Crear() {
        System.out.println("Dame el nombre del gerente");
        nombre = scanner.nextLine();
        System.out.println("Dame la edad del gerente");
        edad = scanner.nextInt();
        System.out.println("Dame el salario del gerente");
        salario = scanner.nextFloat();
        Gerente gerente = new Gerente(nombre, edad, salario);
        return gerente;
    }

    public void MostrarDatos() {
        System.out.println("El nombre es: " + this.getNombre());
        System.out.println("La edad es: " + this.getEdad());
        System.out.println("Con un salario de: " + this.getSalario());
    }

}
