
import java.util.ArrayList;
import java.util.Scanner;

public class Departamento {
    Scanner scanner = new Scanner(System.in);
    private int numeroDep;
    private String categoria;
    private Empleado empleado;
    private Producto producto;
    int numdep;
    ArrayList<Departamento> departamentos = new ArrayList<>();

    public Departamento() {
    }

    public Departamento(int numeroDep, String categoria, Empleado empleado, Producto producto) {
        this.setNumeroDep(numeroDep);
        this.setCategoria(categoria);
        this.setEmpleado(empleado);
        this.setProducto(producto);
    }

    public void setNumeroDep(int numeroDep) {
        if (numeroDep > 0) {
            this.numeroDep = numeroDep;
        }
    }

    public int getNumeroDep() {
        return numeroDep;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void Crear() {
        System.out.println("Dame el numero de departamentos de la tienda");
        numdep = scanner.nextInt();
        for (int i = 0; i < numdep; i++) {
            System.out.println("Dame el numero del departamento");
            numeroDep = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Dame la categoria del departamento");
            categoria = scanner.nextLine();
            System.out.println("Datos de los empleados:");
            empleado = new Empleado();
            empleado.Crear();
            System.out.println("Datos de los productos");
            producto = new Producto();
            producto.Crear();
            Departamento de = new Departamento(numeroDep, categoria, empleado, producto);
            departamentos.add(de);
        }

    }

    public void MostrarDepartamentos() {
        for (Departamento depart : departamentos) {
            int op;
            System.out.println("\nEl departamento es: " + depart.getCategoria());
            System.out.println("El numero del departamento es: " + depart.getNumeroDep());
            System.out.println("Presiona 1 para ver a los empleados");
            op = scanner.nextInt();
            if (op == 1) {
                depart.getEmpleado().MostrarEmpleado();
            }
            System.out.println("Presiona 1 para ver los productos");
            op = scanner.nextInt();
            if (op == 1) {
                depart.getProducto().MostrarDatos();
            }
        }

    }

}
