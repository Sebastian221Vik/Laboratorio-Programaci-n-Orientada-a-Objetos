import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class EjemplosProyecto {
    public static void main(String[] args) {

        HashSet<String> Identificador = new HashSet<String>();
        int a;
        String palabra = "Hola";
        Identificador.add(palabra);
        Identificador.add("Como");
        Identificador.add("Estas");
        Identificador.add("123");
        Identificador.add("7854");
        a = Identificador.size();
        System.out.println("¿El set esta vacio? " + Identificador.isEmpty());
        Identificador.remove("Como");
        System.out.println("Se acaba de eliminar el elemento: Como");
        System.out.println("El tamaño del set antes de la elimiacion de: Como es de: " + a);
        System.out.println("El set es el siguiente:");
        for (String p : Identificador) {
            System.out.println(p);
        }

        LinkedHashSet<Integer> lista = new LinkedHashSet<Integer>();
        lista.add(2);
        lista.add(3);
        lista.add(1);
        lista.add(5);
        lista.add(4);
        System.out.println("Elementos en la lista: " + lista);

        LinkedHashSet<Integer> lista2 = new LinkedHashSet<Integer>();
        lista2.add(6);
        lista2.add(8);

        lista.addAll(lista2);
        System.out.println("Elementos al agregar lista2: " + lista);

        TreeSet<Integer> lista3 = new TreeSet<Integer>();
        System.out.println("Se agregan los numeros 5,8,1 y 0 en ese orden");
        lista3.add(5);
        lista3.add(8);
        lista3.add(1);
        lista3.add(0);
        for (Integer num : lista3) {
            System.out.println(num);
        }
        System.out.println("Se usa el metodo removeAll para remover los numeros 0,1 y 5 mediante otro TreeSet creado");
        TreeSet<Integer> lista4 = new TreeSet<Integer>();
        lista4.add(1);
        lista4.add(0);
        lista4.add(5);
        lista3.removeAll(lista4);
        for (Integer num : lista3) {
            System.out.println(num);
        }

    }
}
