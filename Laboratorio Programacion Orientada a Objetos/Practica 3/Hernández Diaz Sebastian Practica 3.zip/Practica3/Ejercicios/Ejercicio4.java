import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;
import static java.time.temporal.ChronoUnit.DAYS;

public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // METODO 1

        System.out.println("Dame una fecha con el formato yyyy-mm-dd");
        String fechainicio = scanner.nextLine();
        System.out.println("Dame una fecha con el formato yyyy-mm-dd");
        String fechafin = scanner.nextLine();
        LocalDate fechai = LocalDate.parse(fechainicio);
        LocalDate fechaf = LocalDate.parse(fechafin);
        long dias = DAYS.between(fechai, fechaf);
        System.out.println("Numero de dias: " + dias);

        // METODO 2
        System.out.println("\nDame una fecha con el formato yyyy-mm-dd para sumarle 40 dias");
        String fecha1 = scanner.nextLine();
        LocalDate aumento;
        LocalDate fecha = LocalDate.parse(fecha1);
        aumento = fecha.plusDays(40);
        System.out.println("La fecha " + fecha + " mas 40 dias es: " + aumento);

        // METODO 3
        System.out.println("\nDame una fecha con el formato yyyy-mm-dd");
        String fechad = scanner.nextLine();
        LocalDate fechadada = LocalDate.parse(fechad);
        LocalDate fechaactual = LocalDate.now();
        if (fechaactual.isAfter(fechadada)) {
            long dias2 = DAYS.between(fechadada, fechaactual);
            System.out.println("Numero de dias que han pasado desde la fecha dada: " +
                    dias2);
        } else if (fechaactual.isBefore(fechadada)) {
            long dias2 = DAYS.between(fechaactual, fechadada);
            System.out.println("Numero de dias que faltan para la fecha dada: " + dias2);
        } else if (fechaactual.isEqual(fechadada)) {
            System.out.println("La fecha dada es la de hoy ");
        }

        // METODO 4
        long epoch2 = System.currentTimeMillis() / 1000;
        System.out.println("\nTiempo desde epoch: " + epoch2);
        System.out.println("\nDame una fecha con el formato yyyy-mm-dd");
        String fechaepoch = scanner.nextLine();
        LocalDate fechaep = LocalDate.parse(fechaepoch);
        LocalDate epoch = LocalDate.ofEpochDay(0);
        System.out
                .println("Tiempo desde epoch hasta la fecha dada en dias: " + ChronoUnit.DAYS.between(epoch, fechaep));
        System.out.println("Tiempo en segundos: " + (ChronoUnit.DAYS.between(epoch, fechaep) * 86400));
        scanner.close();
    }
}
