public class Ejercicio1{
	public static void main(String[] args) {
		String cadena1 = args[0];
		String cadena2 = args[1];
		int entero =Integer.parseInt(args[2]);

		System.out.println("Hola "+cadena1);

		System.out.println("Tu nombre es: "+cadena1);
		System.out.println("tu apellido es:"+cadena2);
		System.out.println("Tu edad: "+entero);

	}

}