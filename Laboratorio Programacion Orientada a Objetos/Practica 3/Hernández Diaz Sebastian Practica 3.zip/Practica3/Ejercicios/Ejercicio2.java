public class Ejercicio2 {
    public static void main(String[] args) {
        int elementos[] = { 1, 10, 5, 5, 4, 3, 6, 7, 8, 9 };
        int suma;
        suma = suma(elementos);
        System.out.println(suma);
    }

    public static int suma(int elementos[]) {
        int i, suma = 0;
        int mayor = elementos[0], menor = elementos[0];
        for (i = 0; i < elementos.length; i++) {
            if (elementos[i] > mayor) {
                mayor = elementos[i];
            }
            if (elementos[i] < menor) {
                menor = elementos[i];
            }
        }
        for (i = 0; i < elementos.length; i++) {
            suma += elementos[i];
        }
        suma -= mayor;
        suma -= menor;
        return suma;
    }
}