import java.util.Arrays;
import java.util.List;

public class Ejercicio2Metodos {
    public static void main(String[] args) {
        int lista1[] = { 9, 5, 6, 2, 1, 8 };
        int i = 0;
        System.out.println("Metodo copyOf");
        int lista2[] = Arrays.copyOf(lista1, lista1.length);
        System.out.println("Lista original:");
        for (i = 0; i < lista1.length; i++) {
            System.out.println(lista1[i]);
        }
        System.out.println("Segunda lista:");
        for (i = 0; i < lista2.length; i++) {
            System.out.println(lista2[i]);
        }
        System.out.println("Metodo asList");
        Integer lista[] = new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        List<Integer> li = Arrays.asList(lista);
        System.out.println("La lista generada es: " + li);
        int lista3[] = { 9, 5, 4, 11, 10, 7, 1, 8 };
        int lista4[];
        System.out.println("Metodo copyOfRange");
        lista4 = Arrays.copyOfRange(lista3, 2, 6);
        System.out.println("Lista original:");
        for (i = 0; i < lista3.length; i++) {
            System.out.println(lista3[i]);
        }
        System.out.println("Lista en Rango:");
        for (i = 0; i < lista4.length; i++) {
            System.out.println(lista4[i]);
        }
        System.out.println("Metodo equals");
        System.out.println("Comparacion de lista1 con lista3");
        System.out.println(lista1.equals(lista3));
        System.out.println("Metodo sort");
        System.out.println("Lista original");
        for (i = 0; i < lista3.length; i++) {
            System.out.println(lista3[i]);
        }
        Arrays.sort(lista3);
        System.out.println("Lista ordenada");
        for (i = 0; i < lista3.length; i++) {
            System.out.println(lista3[i]);
        }
        System.out.println("Metodo toString");
        Integer a = 200;
        System.out.println(a.toString());
        System.out.println("Metodo binarySearch");
        System.out.println("Lista utilizada para la busqueda");
        for (i = 0; i < lista4.length; i++) {
            System.out.print(lista4[i] + " ");
        }
        System.out.println("\nEl numero a buscar es 11");
        System.out.println("El indice del numero es: " + Arrays.binarySearch(lista4, 11));

    }
}
